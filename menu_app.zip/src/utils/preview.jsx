import { render } from "preact";
import { Preview } from "../main";

render(<Preview />, document.getElementById("app"));
